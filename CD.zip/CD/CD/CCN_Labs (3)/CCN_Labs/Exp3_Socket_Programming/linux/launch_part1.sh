#!/bin/bash
# ============================================================
# Exp3 Part 1 — Auto-launcher (server + client in split panes)
# Uses tmux if available, otherwise falls back to new terminals
# ============================================================
DIR="$(cd "$(dirname "$0")/.." && pwd)"

launch_tmux() {
    tmux new-session -d -s exp3_p1 -x 200 -y 50 2>/dev/null || \
    tmux kill-session -t exp3_p1 2>/dev/null && \
    tmux new-session -d -s exp3_p1 -x 200 -y 50

    # Left pane: server
    tmux rename-window -t exp3_p1 "Exp3-Part1"
    tmux send-keys -t exp3_p1 "echo '=== SERVER ===' && python3 '$DIR/part1_server.py'" Enter

    # Right pane: client (wait 1s for server to bind)
    tmux split-window -h -t exp3_p1
    tmux send-keys -t exp3_p1 "sleep 1 && echo '=== CLIENT ===' && python3 '$DIR/part1_client.py'" Enter

    tmux select-pane -t exp3_p1:0.0
    tmux attach-session -t exp3_p1
}

launch_xterm() {
    xterm -title "Exp3 Part1 SERVER" -e "python3 '$DIR/part1_server.py'; read -p 'Press Enter to close...'" &
    sleep 1
    xterm -title "Exp3 Part1 CLIENT" -e "python3 '$DIR/part1_client.py'; read -p 'Press Enter to close...'"
}

launch_gnome() {
    gnome-terminal --title="Exp3 Part1 SERVER" -- bash -c "python3 '$DIR/part1_server.py'; read -p 'Press Enter...'" &
    sleep 1
    gnome-terminal --title="Exp3 Part1 CLIENT" -- bash -c "python3 '$DIR/part1_client.py'; read -p 'Press Enter...'"
}

echo ""
echo "  Exp3 Part 1 — Iterative String-Processing Server"
echo "  Launching server + client..."
echo ""

if command -v tmux &>/dev/null; then
    launch_tmux
elif command -v gnome-terminal &>/dev/null; then
    launch_gnome
elif command -v xterm &>/dev/null; then
    launch_xterm
else
    echo "  [TIP] Install tmux for the best experience:  sudo apt install tmux"
    echo ""
    echo "  Starting server in this terminal."
    echo "  Open ANOTHER terminal and run:"
    echo "    python3 $DIR/part1_client.py"
    echo ""
    python3 "$DIR/part1_server.py"
fi
