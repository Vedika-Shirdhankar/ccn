============================================================
  Exp8 — iptables Firewall Management
  WINDOWS NOTE
============================================================

iptables is a Linux-only firewall tool and does NOT run
on Windows natively.

OPTIONS FOR WINDOWS USERS:
─────────────────────────────────────────────────────────

1. WSL (Windows Subsystem for Linux) — RECOMMENDED
   ─────────────────────────────────────────────────
   a) Enable WSL:  Open PowerShell as Administrator and run:
        wsl --install
   b) Restart your PC.
   c) Open Ubuntu from Start Menu.
   d) Navigate to the lab folder:
        cd /mnt/c/path/to/CCN_Labs
   e) Run:
        sudo bash Exp8_iptables/linux/exp8_iptables.sh

2. VirtualBox / VMware
   ─────────────────────────────────────────────────
   Run a Linux VM (Ubuntu/Kali) and copy the CCN_Labs
   folder into it.

3. Windows Firewall equivalent (netsh / PowerShell)
   ─────────────────────────────────────────────────
   For reference, common Windows Firewall commands:

   View all rules:
     netsh advfirewall firewall show rule name=all

   Block a port (e.g. 8080):
     netsh advfirewall firewall add rule name="Block8080" ^
       dir=in action=block protocol=tcp localport=8080

   Delete the rule:
     netsh advfirewall firewall delete rule name="Block8080"

   Reset firewall to defaults:
     netsh advfirewall reset

============================================================
