#!/bin/bash
# ============================================================
#  CCN Labs — Main Menu (Linux)
#  Computer Communication and Networks — A.Y. 2025-26
# ============================================================
DIVIDER="============================================================"
DIR="$(cd "$(dirname "$0")" && pwd)"

show_menu() {
    clear
    echo ""
    echo "$DIVIDER"
    echo "   CCN LABS — MAIN MENU  (Linux)"
    echo "$DIVIDER"
    echo ""
    echo "   TERMINAL EXPERIMENTS:"
    echo "   ──────────────────────────────────────────────────────"
    echo "   1) Exp1_Linux_Commands       — Basic Networking Commands"
    echo "   2) Exp3_Socket_Programming   — Socket Programming (Python)"
    echo "   3) Exp6_Nmap                 — Network Mapping using Nmap"
    echo "   4) Exp7_Scapy                — Packet Crafting using Scapy  [sudo]"
    echo "   5) Exp8_iptables             — iptables Firewall Management  [sudo]"
    echo ""
    echo "   GUI / MANUAL EXPERIMENTS (show instructions):"
    echo "   ──────────────────────────────────────────────────────"
    echo "   6) Exp2_ChromeDevTools       — Chrome DevTools"
    echo "   7) Exp4_CiscoPacketTracer    — Cisco Packet Tracer Subnetting"
    echo "   8) ExpWireshark_HTTP         — Wireshark HTTP Lab"
    echo "   9) Exp10_CiscoProject        — Cisco Packet Tracer Hotel Project"
    echo ""
    echo "   0) Exit"
    echo ""
    echo "$DIVIDER"
    echo ""
}

show_instructions() {
    echo ""
    echo "  ── Instructions: $1 ──"
    echo ""
    grep -A 60 "$1" "$DIR/GUI_EXPERIMENTS_INSTRUCTIONS.txt" 2>/dev/null | head -65
    echo ""
    read -p "  [Press Enter to return to menu...] " _
}

while true; do
    show_menu
    read -p "   Enter choice: " choice
    echo ""

    case "$choice" in
        1)
            bash "$DIR/Exp1_Linux_Commands/linux/exp1_networking_commands.sh"
            ;;
        2)
            bash "$DIR/Exp3_Socket_Programming/linux/run_exp3.sh"
            ;;
        3)
            bash "$DIR/Exp6_Nmap/linux/exp6_nmap.sh"
            ;;
        4)
            bash "$DIR/Exp7_Scapy/linux/run_exp7.sh"
            ;;
        5)
            sudo bash "$DIR/Exp8_iptables/linux/exp8_iptables.sh"
            ;;
        6)
            show_instructions "EXPERIMENT 2"
            ;;
        7)
            show_instructions "EXPERIMENT 4"
            ;;
        8)
            show_instructions "WIRESHARK LAB"
            ;;
        9)
            show_instructions "EXPERIMENT 10"
            ;;
        0)
            echo "   Goodbye!"
            echo ""
            exit 0
            ;;
        *)
            echo "   Invalid choice. Please try again."
            sleep 1
            ;;
    esac
done
