import socket
import threading

HOST = '127.0.0.1'
PORT = 5000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind((HOST, PORT))

server.listen()

print("Chat Server Running...")

clients = []

def broadcast(message, sender_conn):

    for client in clients:

        if client != sender_conn:

            try:
                client.send(message)
            except:
                clients.remove(client)

def handle_client(conn, addr):

    print(f"{addr} connected.")

    while True:

        try:
            message = conn.recv(1024)

            if not message:
                break

            broadcast(message, conn)

        except:
            break

    clients.remove(conn)

    conn.close()

    print(f"{addr} disconnected.")

while True:

    conn, addr = server.accept()

    clients.append(conn)

    thread = threading.Thread(target=handle_client, args=(conn, addr))

    thread.start()