# ICMP ping req

from scapy.all import *

packet = IP(dst="8.8.8.8")/ICMP()

packet.show()

reply = sr1(packet)

reply.show()


# UDP datagram
from scapy.all import *


packet = IP(dst="8.8.8.8")/UDP(dport=53)/Raw(load="Hello")# for DNS port and Raw for content

packet.show()

reply = sr1(packet, timeout=2)

print(reply)


# DNS query 

from scapy.all import *

packet = IP(dst="8.8.8.8")/UDP(dport=53)/DNS(
    rd=1,
    qd=DNSQR(qname="google.com")
) # rd -> recursively resolve this domain, DNSQR -> dns question record..

packet.show()

reply = sr1(packet, timeout=3)

reply.show()


## Simple http request
from scapy.all import *

packet = IP(dst="example.com")/TCP(dport=80, flags="S") # S -> syn packet for starting HTTP connection..

packet.show()

reply = sr1(packet)

reply.show()


## Traceroute
from scapy.all import *

target = "8.8.8.8"

for ttl in range(1, 10):

    packet = IP(dst=target, ttl=ttl)/UDP(dport=33434)

    reply = sr1(packet, timeout=2, verbose=0)

    if reply is None:
        print(ttl, "*")

    else:
        print(ttl, reply.src)

        if reply.src == target:
            break