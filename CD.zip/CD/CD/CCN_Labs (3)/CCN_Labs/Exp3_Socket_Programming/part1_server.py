#!/usr/bin/env python3
"""
Experiment 3 - Part 1: TCP String Processing Server (Iterative)

Run this FIRST, then run part1_client.py in another terminal.
"""
import socket

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(('0.0.0.0', 6001))
    server_socket.listen(1)
    print("=" * 55)
    print("  Part 1 Server listening on port 6001...")
    print("  Waiting for a single client...")
    print("=" * 55)

    conn, addr = server_socket.accept()
    print(f"  Connected by: {addr}")

    with conn:
        data = conn.recv(4096).decode()
        if data:
            print(f"  Received: {data.strip()}")
            num_chars     = len(data.strip('\n'))
            num_words     = len(data.split())
            num_sentences = data.count('.')

            response = (f"Characters : {num_chars}\n"
                        f"Words      : {num_words}\n"
                        f"Sentences  : {num_sentences}")
            conn.sendall(response.encode())
            print("  Response sent.")

    server_socket.close()
    print("  Server closed.")

if __name__ == "__main__":
    start_server()
