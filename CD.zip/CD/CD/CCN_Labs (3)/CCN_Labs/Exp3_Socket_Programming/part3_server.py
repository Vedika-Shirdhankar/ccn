#!/usr/bin/env python3
"""
Experiment 3 - Part 3: Group Chat Server

Run this first. Clients connect using part3_client.py.
All connected clients receive each other's messages (broadcast).
"""
import socket
import threading

clients = {}  # socket -> name
lock    = threading.Lock()

def broadcast(message, sender_socket=None):
    """Send message to all clients except the sender."""
    with lock:
        for client_sock in list(clients):
            if client_sock != sender_socket:
                try:
                    client_sock.send(message)
                except:
                    client_sock.close()
                    del clients[client_sock]

def handle_client(client_socket, addr):
    try:
        client_socket.send(b"Enter your name: ")
        name = client_socket.recv(1024).decode().strip()
        with lock:
            clients[client_socket] = name
        print(f"  [{name}] joined from {addr}")
        broadcast(f"\n  --- {name} has joined the chat ---\n".encode(), client_socket)
        client_socket.send(f"  Welcome {name}! Type messages to chat.\n".encode())

        while True:
            msg = client_socket.recv(1024)
            if not msg:
                break
            formatted = f"  [{name}]: {msg.decode().strip()}\n".encode()
            print(formatted.decode(), end="")
            broadcast(formatted, client_socket)

    except:
        pass
    finally:
        with lock:
            name = clients.pop(client_socket, "Unknown")
        broadcast(f"\n  --- {name} has left the chat ---\n".encode())
        client_socket.close()
        print(f"  [{name}] disconnected.")

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind(('0.0.0.0', 65432))
server.listen()
print("=" * 55)
print("  Part 3 Chat Server listening on port 65432")
print("  Open 2+ terminals and run: python3 part3_client.py")
print("  Press Ctrl+C to stop.")
print("=" * 55)
try:
    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr))
        thread.daemon = True
        thread.start()
except KeyboardInterrupt:
    print("\n  Server shutting down.")
finally:
    server.close()
