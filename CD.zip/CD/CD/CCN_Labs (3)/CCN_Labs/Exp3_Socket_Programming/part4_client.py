#!/usr/bin/env python3
"""
Experiment 3 - Part 4: Advanced Chat Client (Group + DM)

  - Normal message  → goes to all users
  - @username msg   → direct message
"""
import socket
import threading

def receive(sock):
    while True:
        try:
            msg = sock.recv(1024).decode()
            if not msg:
                break
            print(msg, end="", flush=True)
        except:
            print("  [Disconnected from server]")
            break

HOST = input("Server IP (press Enter for localhost): ").strip() or '127.0.0.1'
PORT = 5003

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

recv_thread = threading.Thread(target=receive, args=(client,))
recv_thread.daemon = True
recv_thread.start()

try:
    while True:
        msg = input()
        if msg.lower() in ('/quit', '/exit'):
            break
        client.send(msg.encode())
except (KeyboardInterrupt, EOFError):
    pass
finally:
    client.close()
    print("  Disconnected.")
