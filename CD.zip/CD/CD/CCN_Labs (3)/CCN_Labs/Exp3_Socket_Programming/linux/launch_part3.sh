#!/bin/bash
# ============================================================
# Exp3 Part 3 — Auto-launcher (Group Chat: server + 2 clients)
# ============================================================
DIR="$(cd "$(dirname "$0")/.." && pwd)"

launch_tmux() {
    tmux kill-session -t exp3_p3 2>/dev/null
    tmux new-session -d -s exp3_p3 -x 220 -y 55

    tmux rename-window -t exp3_p3 "Exp3-Part3-Chat"

    # Left: server
    tmux send-keys -t exp3_p3 "echo '=== GROUP CHAT SERVER (port 65432) ===' && python3 '$DIR/part3_server.py'" Enter

    # Top-right: client Alice
    tmux split-window -h -t exp3_p3
    tmux send-keys -t exp3_p3 "sleep 1 && echo '=== CLIENT: connect and enter name ===' && python3 '$DIR/part3_client.py'" Enter

    # Bottom-right: client Bob
    tmux split-window -v -t exp3_p3:0.1
    tmux send-keys -t exp3_p3 "sleep 1 && echo '=== CLIENT: connect and enter name ===' && python3 '$DIR/part3_client.py'" Enter

    tmux select-pane -t exp3_p3:0.1
    echo ""
    echo "  Attaching tmux session (Group Chat)..."
    echo "  Enter a name in each client pane to join the chat."
    echo "  Ctrl+B arrow keys = switch panes | Ctrl+B D = detach"
    echo ""
    sleep 1
    tmux attach-session -t exp3_p3
}

launch_gnome() {
    gnome-terminal --title="Exp3 P3 SERVER"   -- bash -c "python3 '$DIR/part3_server.py'; read -p 'Press Enter...'" &
    sleep 1
    gnome-terminal --title="Exp3 P3 Alice"    -- bash -c "python3 '$DIR/part3_client.py'; read -p 'Press Enter...'" &
    sleep 0.3
    gnome-terminal --title="Exp3 P3 Bob"      -- bash -c "python3 '$DIR/part3_client.py'; read -p 'Press Enter...'"
}

launch_xterm() {
    xterm -title "Exp3 P3 SERVER"  -geometry 80x24+0+0   -e "python3 '$DIR/part3_server.py'; read -p 'Press Enter...'" &
    sleep 1
    xterm -title "Exp3 P3 Alice"   -geometry 80x24+820+0 -e "python3 '$DIR/part3_client.py'; read -p 'Press Enter...'" &
    sleep 0.3
    xterm -title "Exp3 P3 Bob"     -geometry 80x24+820+300 -e "python3 '$DIR/part3_client.py'; read -p 'Press Enter...'"
}

echo ""
echo "  Exp3 Part 3 — Group Chat Server"
echo "  Launching server + 2 chat clients..."
echo ""

if command -v tmux &>/dev/null; then
    launch_tmux
elif command -v gnome-terminal &>/dev/null; then
    launch_gnome
elif command -v xterm &>/dev/null; then
    launch_xterm
else
    echo "  [TIP] Install tmux:  sudo apt install tmux"
    echo ""
    echo "  Starting server here. Open 2 more terminals and run:"
    echo "    python3 $DIR/part3_client.py"
    echo ""
    python3 "$DIR/part3_server.py"
fi
