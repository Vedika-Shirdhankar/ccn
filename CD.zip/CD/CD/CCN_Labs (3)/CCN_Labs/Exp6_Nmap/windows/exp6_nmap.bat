@echo off
:: ============================================================
:: Exp6_Nmap — Windows Runner
:: Falls back to Python port scanner if nmap not installed
:: ============================================================

:: Detect python
set PYEXE=
py --version >nul 2>&1 && set PYEXE=py
if "%PYEXE%"=="" (python3 --version >nul 2>&1 && set PYEXE=python3)
if "%PYEXE%"=="" (python --version >nul 2>&1 && set PYEXE=python)

:: Check nmap
nmap --version >nul 2>&1
if %errorlevel%==0 goto use_nmap

:: ── Nmap not found — use Python fallback ──────────────────
echo.
echo   [INFO] nmap not found. Using Python fallback scanner.
echo   Install nmap anytime from: https://nmap.org/download.html
echo.
if "%PYEXE%"=="" (
    echo   [ERROR] Python also not found.
    echo   Install Python from https://python.org
    echo   OR install nmap from https://nmap.org/download.html
    pause & exit /b 1
)
%PYEXE% "%~dp0..\exp6_fallback.py"
goto end

:: ── Nmap found ────────────────────────────────────────────
:use_nmap
:menu
cls
echo.
echo ============================================================
echo   Exp6 -- Network Mapping using Nmap
echo   NOTE: Only scan networks you own or have permission for.
echo ============================================================
echo.
echo    1)  Ping scan         (host discovery)
echo    2)  Service + version detection
echo    3)  OS detection      (run as Administrator)
echo    4)  Stealth SYN scan  (run as Administrator)
echo    5)  Scan port range
echo    6)  Aggressive scan   (-A)
echo    7)  Scan localhost    (127.0.0.1)
echo    8)  Custom nmap command
echo    9)  Switch to Python fallback scanner
echo.
echo    0)  Exit
echo.
echo ============================================================
echo.
set /p choice="  Enter choice: "

if "%choice%"=="1" goto ping_scan
if "%choice%"=="2" goto service_scan
if "%choice%"=="3" goto os_scan
if "%choice%"=="4" goto stealth_scan
if "%choice%"=="5" goto port_range
if "%choice%"=="6" goto aggressive
if "%choice%"=="7" goto localhost_scan
if "%choice%"=="8" goto custom
if "%choice%"=="9" (
    if not "%PYEXE%"=="" (%PYEXE% "%~dp0..\exp6_fallback.py") else (echo Python not found.) & goto end
)
if "%choice%"=="0" goto end
echo   Invalid choice. & pause & goto menu

:ping_scan
set /p target="  Target IP or range (e.g. 192.168.1.0/24): "
nmap -sn %target% & pause & goto menu

:service_scan
set /p target="  Target IP: "
nmap -sV %target% & pause & goto menu

:os_scan
set /p target="  Target IP: "
nmap -O %target% & pause & goto menu

:stealth_scan
set /p target="  Target IP: "
nmap -sS %target% & pause & goto menu

:port_range
set /p target="  Target IP: "
set /p ports="  Port range (e.g. 1-1000): "
nmap -p %ports% %target% & pause & goto menu

:aggressive
set /p target="  Target IP: "
nmap -A %target% & pause & goto menu

:localhost_scan
nmap -sV 127.0.0.1 & pause & goto menu

:custom
set /p cmd="  nmap command (after 'nmap '): "
nmap %cmd% & pause & goto menu

:end
