#!/usr/bin/env python3
"""
Experiment 3 - Part 3: Chat Client

Run multiple instances in separate terminals to chat.
"""
import socket
import threading
import sys

def receive(sock):
    while True:
        try:
            msg = sock.recv(1024).decode()
            if not msg:
                break
            print(msg, end="", flush=True)
        except:
            print("  [Disconnected from server]")
            break

HOST = input("Server IP (press Enter for localhost): ").strip() or '127.0.0.1'
PORT = 65432

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((HOST, PORT))
print(f"  Connected to chat server at {HOST}:{PORT}")

recv_thread = threading.Thread(target=receive, args=(sock,))
recv_thread.daemon = True
recv_thread.start()

try:
    while True:
        msg = input()
        if msg.lower() in ('/quit', '/exit'):
            break
        sock.send(msg.encode())
except (KeyboardInterrupt, EOFError):
    pass
finally:
    sock.close()
    print("  Disconnected.")
