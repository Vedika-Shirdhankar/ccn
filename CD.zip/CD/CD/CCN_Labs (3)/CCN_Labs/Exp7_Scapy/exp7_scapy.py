#!/usr/bin/env python3
"""
Experiment 7 — Packet Crafting using Scapy

Objective: Craft ICMP, UDP, DNS, HTTP GET, and Traceroute packets.

REQUIREMENTS:
  pip install scapy
  Linux : sudo python3 exp7_scapy.py
  Windows: Run as Administrator + install Npcap from https://npcap.com
"""

import sys
import os
import ctypes

# ── Cross-platform admin / root check ──────────────────────
def check_privileges():
    if sys.platform == "win32":
        try:
            is_admin = ctypes.windll.shell32.IsUserAnAdmin()
        except:
            is_admin = False
        if not is_admin:
            print("\n[WARNING] Not running as Administrator.")
            print("  Some Scapy features may fail.")
            print("  Right-click run_exp7.bat → 'Run as administrator'\n")
    else:
        if os.geteuid() != 0:
            print("\n[ERROR] Scapy requires root privileges on Linux.")
            print("  Run with:  sudo python3 exp7_scapy.py\n")
            sys.exit(1)

check_privileges()

try:
    from scapy.all import (IP, ICMP, UDP, TCP, DNS, DNSQR,
                           Raw, sr1, send, sr, conf)
    conf.verb = 0  # suppress verbose output
except ImportError:
    print("\n[ERROR] Scapy not installed.")
    print("  Install:  pip install scapy")
    if sys.platform == "win32":
        print("  Also install Npcap from: https://npcap.com")
    sys.exit(1)

DIVIDER = "=" * 55

def pause():
    input("\n  [Press Enter to continue...] ")
    print()

def task1_icmp_ping():
    print(DIVIDER)
    print("  Task 1: ICMP Echo Request (Ping)")
    print(DIVIDER)
    target = input("  Enter target IP (press Enter for 8.8.8.8): ").strip() or "8.8.8.8"
    print(f"\n  Crafting ICMP Echo Request to {target}...")
    packet = IP(dst=target) / ICMP()
    print("  Packet summary:")
    packet.show()
    print(f"\n  Sending packet to {target}...")
    reply = sr1(packet, timeout=3)
    if reply:
        print("  OK Received ICMP Echo Reply!")
        reply.show()
    else:
        print("  No reply received (host may be unreachable or ICMP blocked).")
    pause()

def task2_udp():
    print(DIVIDER)
    print("  Task 2: UDP Datagram with Custom Payload")
    print(DIVIDER)
    target  = input("  Target IP (press Enter for 127.0.0.1): ").strip() or "127.0.0.1"
    port    = int(input("  Target UDP port (press Enter for 12345): ").strip() or "12345")
    payload = input("  Payload text (press Enter for 'Hello UDP'): ").strip() or "Hello UDP"
    print(f"\n  Crafting UDP packet to {target}:{port}...")
    packet = IP(dst=target) / UDP(dport=port) / Raw(load=payload.encode())
    print("  Packet summary:")
    packet.show()
    print("\n  Sending UDP packet...")
    send(packet)
    print("  UDP packet sent.")
    pause()

def task3_dns():
    print(DIVIDER)
    print("  Task 3: DNS Query")
    print(DIVIDER)
    domain     = input("  Domain to query (press Enter for google.com): ").strip() or "google.com"
    dns_server = input("  DNS server IP (press Enter for 8.8.8.8): ").strip() or "8.8.8.8"
    print(f"\n  Crafting DNS query for '{domain}' to {dns_server}...")
    packet = (IP(dst=dns_server) /
              UDP(dport=53) /
              DNS(rd=1, qd=DNSQR(qname=domain)))
    print("  Packet summary:")
    packet.show()
    print("\n  Sending DNS query...")
    reply = sr1(packet, timeout=5)
    if reply and reply.haslayer(DNS):
        print("  DNS Response received!")
        print(f"  Answer: {reply[DNS].an}")
    else:
        print("  No DNS reply received.")
    pause()

def task4_http_get():
    print(DIVIDER)
    print("  Task 4: HTTP GET Request")
    print(DIVIDER)
    target   = input("  Web server IP (press Enter for 93.184.216.34 [example.com]): ").strip() or "93.184.216.34"
    http_req = (b"GET / HTTP/1.1\r\n"
                b"Host: example.com\r\n"
                b"Connection: close\r\n\r\n")
    print(f"\n  Crafting HTTP GET to {target}:80...")
    pkt = IP(dst=target) / TCP(dport=80, sport=12345, seq=1000, flags="PA") / Raw(load=http_req)
    pkt.show()
    print("\n  Sending raw HTTP GET packet...")
    send(pkt)
    print("  HTTP GET packet sent.")
    pause()

def task5_traceroute():
    print(DIVIDER)
    print("  Task 5: Traceroute (UDP with increasing TTL)")
    print(DIVIDER)
    target   = input("  Target IP (press Enter for 8.8.8.8): ").strip() or "8.8.8.8"
    max_hops = 15
    print(f"\n  Tracerouting to {target} (max {max_hops} hops)...")
    print(f"  {'HOP':<5} {'IP':<20} {'RTT':>8}")
    print(f"  {'-'*4} {'-'*20} {'-'*8}")
    import time
    for ttl in range(1, max_hops + 1):
        pkt   = IP(dst=target, ttl=ttl) / UDP(dport=33434 + ttl)
        start = time.time()
        reply = sr1(pkt, timeout=2)
        rtt   = (time.time() - start) * 1000
        if reply is None:
            print(f"  {ttl:<5} {'* * *':<20} {'timeout':>8}")
        else:
            print(f"  {ttl:<5} {reply.src:<20} {rtt:>7.1f}ms")
            if reply.src == target:
                print(f"\n  Reached destination {target}!")
                break
    pause()

def main():
    print()
    print(DIVIDER)
    print("  EXPERIMENT 7 — Packet Crafting using Scapy")
    print(DIVIDER)
    print()
    tasks = {
        "1": ("ICMP Echo Request (Ping)",         task1_icmp_ping),
        "2": ("UDP Datagram with Custom Payload",  task2_udp),
        "3": ("DNS Query",                         task3_dns),
        "4": ("HTTP GET Request",                  task4_http_get),
        "5": ("Traceroute (UDP + TTL)",            task5_traceroute),
        "6": ("Run All Tasks",                     None),
        "0": ("Exit",                              None),
    }
    for k, (label, _) in tasks.items():
        print(f"    {k}) {label}")
    print()
    choice = input("  Select task: ").strip()

    if choice == "6":
        for k in ["1","2","3","4","5"]:
            tasks[k][1]()
    elif choice == "0":
        print("  Exiting.")
    elif choice in tasks:
        tasks[choice][1]()
    else:
        print("  Invalid choice.")

if __name__ == "__main__":
    main()
