#!/bin/bash
# ============================================================
# Exp6_Nmap — Linux Runner
# Falls back to Python port scanner if nmap not installed
# ============================================================
DIVIDER="============================================================"
DIR="$(cd "$(dirname "$0")/.." && pwd)"

# Check nmap
if ! command -v nmap &>/dev/null; then
    echo ""
    echo "  [INFO] nmap not installed. Using Python fallback scanner."
    echo "  Install nmap anytime:  sudo apt install nmap"
    echo ""
    # Find python
    PYEXE=""
    command -v python3 &>/dev/null && PYEXE="python3"
    [ -z "$PYEXE" ] && command -v python &>/dev/null && PYEXE="python"
    if [ -z "$PYEXE" ]; then
        echo "  [ERROR] Python also not found."
        echo "  Install with:  sudo apt install python3"
        exit 1
    fi
    $PYEXE "$DIR/exp6_fallback.py"
    exit 0
fi

# ── Nmap found ────────────────────────────────────────────
show_menu() {
    clear
    echo ""
    echo "$DIVIDER"
    echo "  Exp6 — Network Mapping using Nmap"
    echo "  NOTE: Only scan networks you own or have permission for."
    echo "$DIVIDER"
    echo ""
    echo "   1) Ping scan          (host discovery)"
    echo "   2) Service + version detection"
    echo "   3) OS detection       [needs sudo]"
    echo "   4) Stealth SYN scan   [needs sudo]"
    echo "   5) Scan port range"
    echo "   6) Aggressive scan    (-A)"
    echo "   7) Scan localhost     (127.0.0.1)"
    echo "   8) Custom nmap command"
    echo "   9) Switch to Python fallback scanner"
    echo ""
    echo "   0) Exit"
    echo ""
    echo "$DIVIDER"
    echo ""
}

while true; do
    show_menu
    read -p "  Enter choice: " choice
    echo ""
    case $choice in
        1)
            read -p "  Target IP or range (e.g. 192.168.1.0/24): " target
            nmap -sn "$target" ;;
        2)
            read -p "  Target IP: " target
            nmap -sV "$target" ;;
        3)
            read -p "  Target IP: " target
            sudo nmap -O "$target" ;;
        4)
            read -p "  Target IP: " target
            sudo nmap -sS "$target" ;;
        5)
            read -p "  Target IP: " target
            read -p "  Port range (e.g. 1-1000): " ports
            nmap -p "$ports" "$target" ;;
        6)
            read -p "  Target IP: " target
            nmap -A "$target" ;;
        7)
            nmap -sV 127.0.0.1 ;;
        8)
            read -p "  nmap command (after 'nmap '): " cmd
            nmap $cmd ;;
        9)
            PYEXE=""
            command -v python3 &>/dev/null && PYEXE="python3"
            [ -z "$PYEXE" ] && command -v python &>/dev/null && PYEXE="python"
            if [ -n "$PYEXE" ]; then
                $PYEXE "$DIR/exp6_fallback.py"
            else
                echo "  Python not found. Install with: sudo apt install python3"
            fi ;;
        0)
            echo "  Goodbye!" ; exit 0 ;;
        *)
            echo "  Invalid choice." ;;
    esac
    echo ""
    read -p "  [Press Enter to continue...] " _
done
