import socket

HOST = '127.0.0.1'
PORT = 5000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind((HOST, PORT))

server.listen(1)

print("Server is running...")

conn, addr = server.accept()

print(f"Connected by {addr}")

data = conn.recv(1024).decode()

characters = len(data)
words = len(data.split())
sentences = data.count('.')

result = f"Characters: {characters}\nWords: {words}\nSentences: {sentences}"

conn.send(result.encode())

conn.close()
server.close()