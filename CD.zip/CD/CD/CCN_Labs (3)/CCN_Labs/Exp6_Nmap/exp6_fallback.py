#!/usr/bin/env python3
"""
Experiment 6 — Network Scanner (Nmap Fallback)

Used automatically when nmap is not installed.
Uses Python's built-in socket module — no extra installs needed.
Works on both Linux and Windows.
"""

import socket
import subprocess
import sys
import os
import threading
from datetime import datetime

DIVIDER = "=" * 55

def pause():
    input("\n  [Press Enter to continue...] ")
    print()

# ── 1. Ping a host ───────────────────────────────────────────
def ping_host(host):
    param = "-n" if sys.platform == "win32" else "-c"
    result = subprocess.run(
        ["ping", param, "4", host],
        capture_output=True, text=True
    )
    print(result.stdout)
    if result.returncode == 0:
        print(f"  Host {host} is UP")
    else:
        print(f"  Host {host} is DOWN or unreachable")

# ── 2. Port scan ─────────────────────────────────────────────
def scan_port(host, port, open_ports, lock):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.5)
        result = s.connect_ex((host, port))
        if result == 0:
            try:
                service = socket.getservbyport(port)
            except:
                service = "unknown"
            with lock:
                open_ports.append((port, service))
        s.close()
    except:
        pass

def port_scan(host, start_port, end_port):
    print(f"\n  Scanning {host} ports {start_port}-{end_port}...")
    print(f"  Started at: {datetime.now().strftime('%H:%M:%S')}\n")
    open_ports = []
    lock = threading.Lock()
    threads = []
    for port in range(start_port, end_port + 1):
        t = threading.Thread(target=scan_port, args=(host, port, open_ports, lock))
        t.daemon = True
        threads.append(t)
        t.start()
        # Limit concurrent threads
        if len(threads) >= 200:
            for t in threads:
                t.join()
            threads = []
    for t in threads:
        t.join()

    open_ports.sort()
    if open_ports:
        print(f"  {'PORT':<8} {'SERVICE':<20} STATUS")
        print(f"  {'-'*7} {'-'*20} ------")
        for port, svc in open_ports:
            print(f"  {port:<8} {svc:<20} open")
        print(f"\n  {len(open_ports)} open port(s) found.")
    else:
        print("  No open ports found in that range.")
    print(f"\n  Finished at: {datetime.now().strftime('%H:%M:%S')}")

# ── 3. DNS lookup ────────────────────────────────────────────
def dns_lookup(host):
    try:
        ip = socket.gethostbyname(host)
        print(f"\n  {host}  →  {ip}")
        try:
            hostname = socket.gethostbyaddr(ip)
            print(f"  Reverse DNS: {hostname[0]}")
        except:
            pass
    except socket.gaierror as e:
        print(f"\n  DNS lookup failed: {e}")

# ── 4. Banner grab ───────────────────────────────────────────
def banner_grab(host, port):
    try:
        s = socket.socket()
        s.settimeout(3)
        s.connect((host, port))
        s.send(b"HEAD / HTTP/1.0\r\n\r\n")
        banner = s.recv(1024).decode(errors="ignore").strip()
        s.close()
        print(f"\n  Banner from {host}:{port}:")
        print(f"  {banner[:300]}")
    except Exception as e:
        print(f"\n  Could not grab banner: {e}")

# ── 5. Ping sweep (local subnet) ─────────────────────────────
def ping_sweep(subnet_base, count=10):
    """e.g. subnet_base = '192.168.1' scans .1 to .count"""
    print(f"\n  Pinging {subnet_base}.1 to {subnet_base}.{count}...")
    print(f"  (This may take a moment)\n")
    param = "-n" if sys.platform == "win32" else "-c"
    up = []
    threads = []

    def check(ip):
        r = subprocess.run(["ping", param, "1", "-W" if sys.platform != "win32" else "/w", "500", ip],
                           capture_output=True)
        if r.returncode == 0:
            up.append(ip)
            print(f"  {ip:<20} UP")

    for i in range(1, count + 1):
        ip = f"{subnet_base}.{i}"
        t = threading.Thread(target=check, args=(ip,))
        t.daemon = True
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    print(f"\n  {len(up)} host(s) found up.")

# ── Main menu ────────────────────────────────────────────────
def main():
    print()
    print(DIVIDER)
    print("  Exp6 — Network Scanner  [Nmap Fallback - Python]")
    print("  No nmap needed — uses built-in socket module")
    print(DIVIDER)

    while True:
        print()
        print("   1) Ping a host")
        print("   2) Port scan (range)")
        print("   3) Port scan (common ports: 1-1024)")
        print("   4) DNS lookup")
        print("   5) Banner grab (HTTP header)")
        print("   6) Ping sweep (scan .1 to .20 on a subnet)")
        print("   0) Exit")
        print()
        choice = input("  Enter choice: ").strip()

        if choice == "1":
            host = input("  Enter hostname or IP: ").strip()
            ping_host(host)
            pause()

        elif choice == "2":
            host  = input("  Target IP or hostname: ").strip()
            start = int(input("  Start port (e.g. 1): ").strip() or "1")
            end   = int(input("  End port   (e.g. 1024): ").strip() or "1024")
            port_scan(host, start, end)
            pause()

        elif choice == "3":
            host = input("  Target IP or hostname: ").strip()
            port_scan(host, 1, 1024)
            pause()

        elif choice == "4":
            host = input("  Enter domain or IP: ").strip()
            dns_lookup(host)
            pause()

        elif choice == "5":
            host = input("  Target IP or hostname: ").strip()
            port = int(input("  Port (press Enter for 80): ").strip() or "80")
            banner_grab(host, port)
            pause()

        elif choice == "6":
            subnet = input("  Subnet base (e.g. 192.168.1): ").strip()
            count  = int(input("  Scan .1 to .? (press Enter for 20): ").strip() or "20")
            ping_sweep(subnet, count)
            pause()

        elif choice == "0":
            print("  Exiting.")
            break
        else:
            print("  Invalid choice.")

if __name__ == "__main__":
    main()
