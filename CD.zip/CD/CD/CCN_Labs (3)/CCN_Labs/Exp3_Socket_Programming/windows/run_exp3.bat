@echo off
:: ============================================================
:: Exp3_Socket_Programming — Windows Runner
:: ============================================================
set PYDIR=%~dp0..
set WINDIR=%~dp0

:: Detect correct python command
set PYEXE=
py --version >nul 2>&1 && set PYEXE=py
if "%PYEXE%"=="" (python3 --version >nul 2>&1 && set PYEXE=python3)
if "%PYEXE%"=="" (python --version >nul 2>&1 && set PYEXE=python)
if "%PYEXE%"=="" (
    echo.
    echo   [ERROR] Python not found.
    echo   Install from https://python.org and tick "Add Python to PATH"
    echo   OR open Microsoft Store and search "Python 3"
    echo.
    pause
    exit /b 1
)

:menu
cls
echo.
echo ============================================================
echo   Exp3 -- Socket Programming
echo ============================================================
echo.
echo   AUTO-LAUNCH (opens all needed windows automatically):
echo   ----------------------------------------------------
echo    1) Part 1 -- Iterative server + client      [2 windows]
echo    2) Part 2 -- Concurrent server + 2 clients  [3 windows]
echo    3) Part 3 -- Group chat + 2 clients         [3 windows]
echo    4) Part 4 -- Advanced chat (group + DMs)    [3 windows]
echo.
echo   MANUAL (run one component at a time):
echo   ----------------------------------------------------
echo    5) Part 1 Server only
echo    6) Part 1 Client only
echo    7) Part 2 Server only
echo    8) Part 2 Client only
echo    9) Part 3 Server only
echo   10) Part 3 Client only
echo   11) Part 4 Server only
echo   12) Part 4 Client only
echo.
echo    0) Exit
echo.
echo ============================================================
echo.
set /p choice="  Enter choice: "

if "%choice%"=="1"  goto launch_p1
if "%choice%"=="2"  call "%WINDIR%launch_part2.bat" & goto menu
if "%choice%"=="3"  goto launch_p3
if "%choice%"=="4"  goto launch_p4
if "%choice%"=="5"  start "Exp3 P1 Server" cmd /k "%PYEXE% "%PYDIR%\part1_server.py"" & goto menu
if "%choice%"=="6"  start "Exp3 P1 Client" cmd /k "%PYEXE% "%PYDIR%\part1_client.py"" & goto menu
if "%choice%"=="7"  start "Exp3 P2 Server" cmd /k "%PYEXE% "%PYDIR%\part2_server.py"" & goto menu
if "%choice%"=="8"  start "Exp3 P2 Client" cmd /k "%PYEXE% "%PYDIR%\part2_client.py"" & goto menu
if "%choice%"=="9"  start "Exp3 P3 Server" cmd /k "%PYEXE% "%PYDIR%\part3_server.py"" & goto menu
if "%choice%"=="10" start "Exp3 P3 Client" cmd /k "%PYEXE% "%PYDIR%\part3_client.py"" & goto menu
if "%choice%"=="11" start "Exp3 P4 Server" cmd /k "%PYEXE% "%PYDIR%\part4_server.py"" & goto menu
if "%choice%"=="12" start "Exp3 P4 Client" cmd /k "%PYEXE% "%PYDIR%\part4_client.py"" & goto menu
if "%choice%"=="0"  goto end
echo   Invalid choice.
pause
goto menu

:launch_p1
start "Exp3-P1 SERVER" cmd /k "echo === SERVER === && %PYEXE% "%PYDIR%\part1_server.py""
timeout /t 1 /nobreak > nul
start "Exp3-P1 CLIENT" cmd /k "echo === CLIENT === && %PYEXE% "%PYDIR%\part1_client.py""
goto menu

:launch_p3
start "Exp3-P3 SERVER" cmd /k "echo === GROUP CHAT SERVER === && %PYEXE% "%PYDIR%\part3_server.py""
timeout /t 1 /nobreak > nul
start "Exp3-P3 Alice"  cmd /k "echo === CLIENT - enter your name === && %PYEXE% "%PYDIR%\part3_client.py""
start "Exp3-P3 Bob"    cmd /k "echo === CLIENT - enter your name === && %PYEXE% "%PYDIR%\part3_client.py""
goto menu

:launch_p4
start "Exp3-P4 SERVER"   cmd /k "echo === ADVANCED CHAT SERVER === && %PYEXE% "%PYDIR%\part4_server.py""
timeout /t 1 /nobreak > nul
start "Exp3-P4 Client-1" cmd /k "echo === CLIENT 1 (type @name msg for DM) === && %PYEXE% "%PYDIR%\part4_client.py""
start "Exp3-P4 Client-2" cmd /k "echo === CLIENT 2 (type @name msg for DM) === && %PYEXE% "%PYDIR%\part4_client.py""
goto menu

:end
echo   Goodbye!
