#!/bin/bash
# ============================================================
# Experiment 8 (Lab 8) — iptables Firewall Management

# WARNING: Rules added here affect live network traffic.
#          All rules are flushed at the end of the demo.
# ============================================================

DIVIDER="============================================================"

check_root() {
    if [ "$EUID" -ne 0 ]; then
        echo "  [ERROR] iptables requires root privileges."
        echo "  Run with:  sudo bash exp8_iptables.sh"
        exit 1
    fi
}

pause() { read -p "  [Press Enter to continue...] " _; echo ""; }

cleanup() {
    echo ""
    echo "$DIVIDER"
    echo "  CLEANUP — Flushing all demo rules..."
    echo "$DIVIDER"
    iptables -F
    iptables -X
    echo "  ✓ All rules flushed. Chain policies unchanged."
}

echo ""
echo "$DIVIDER"
echo "  EXPERIMENT 8 — iptables Firewall Management"
echo "$DIVIDER"
check_root

trap cleanup EXIT   # auto-flush on exit

# ── Exercise 1: View Current Rules ──────────────────────────
echo ""
echo "── Step 1: View Current iptables Rules ──"
echo "  Command: iptables -L"
echo ""
iptables -L
pause

echo "  Command: iptables -L -v (verbose)"
echo ""
iptables -L -v
pause

echo "  Command: iptables -v -L INPUT (INPUT chain only)"
echo ""
iptables -v -L INPUT
pause

echo "  Command: iptables -t mangle -L (mangle table)"
echo ""
iptables -t mangle -L
pause

# ── Exercise 2: Block an IP ──────────────────────────────────
echo "$DIVIDER"
echo "  Step 2: Block Incoming Traffic from a Specific IP"
echo "$DIVIDER"
read -p "  Enter IP to block (press Enter for 192.168.100.200): " BLOCK_IP
BLOCK_IP=${BLOCK_IP:-192.168.100.200}
echo ""
echo "  Command: iptables -A INPUT -s $BLOCK_IP -j DROP"
iptables -A INPUT -s "$BLOCK_IP" -j DROP
echo "  ✓ Rule added. Verifying..."
iptables -L INPUT -v -n
pause

# ── Exercise 3: Allow SSH ────────────────────────────────────
echo "$DIVIDER"
echo "  Step 3: Allow Incoming SSH (port 22)"
echo "$DIVIDER"
echo "  Command: iptables -A INPUT -p tcp --dport 22 -j ACCEPT"
iptables -A INPUT -p tcp --dport 22 -j ACCEPT
echo "  ✓ SSH rule added."
iptables -L INPUT -v -n
pause

# ── Exercise 4: Allow HTTP/HTTPS ─────────────────────────────
echo "$DIVIDER"
echo "  Step 4: Allow HTTP (80) and HTTPS (443)"
echo "$DIVIDER"
echo "  Command: iptables -A INPUT -p tcp --dport 80 -j ACCEPT"
iptables -A INPUT -p tcp --dport 80 -j ACCEPT
echo "  Command: iptables -A INPUT -p tcp --dport 443 -j ACCEPT"
iptables -A INPUT -p tcp --dport 443 -j ACCEPT
echo "  ✓ HTTP/HTTPS rules added."
iptables -L INPUT -v -n
pause

# ── Exercise 5: Block Outgoing to a Port ─────────────────────
echo "$DIVIDER"
echo "  Step 5: Block Outgoing Traffic to Port 23 (Telnet)"
echo "$DIVIDER"
echo "  Command: iptables -A OUTPUT -p tcp --dport 23 -j DROP"
iptables -A OUTPUT -p tcp --dport 23 -j DROP
echo "  ✓ Outgoing Telnet blocked."
iptables -L OUTPUT -v -n
pause

# ── Exercise 6: Allow Established Connections ────────────────
echo "$DIVIDER"
echo "  Step 6: Allow Established/Related Connections (stateful)"
echo "$DIVIDER"
echo "  Command: iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT"
iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
echo "  ✓ Stateful rule added."
pause

# ── Exercise 7: NAT / Masquerade ─────────────────────────────
echo "$DIVIDER"
echo "  Step 7: NAT Masquerade (for internet sharing)"
echo "$DIVIDER"
read -p "  Enter outbound interface (press Enter for eth0): " IFACE
IFACE=${IFACE:-eth0}
echo "  Command: iptables -t nat -A POSTROUTING -o $IFACE -j MASQUERADE"
iptables -t nat -A POSTROUTING -o "$IFACE" -j MASQUERADE 2>/dev/null && \
    echo "  ✓ NAT masquerade added on $IFACE." || \
    echo "  [Note] Interface $IFACE may not exist; rule skipped."
iptables -t nat -L POSTROUTING -v -n
pause

# ── Exercise 8: Save and Show All Rules ──────────────────────
echo "$DIVIDER"
echo "  Step 8: Show All Rules in All Tables"
echo "$DIVIDER"
echo "  ── filter table ──"
iptables -t filter -L -v -n
echo ""
echo "  ── nat table ──"
iptables -t nat -L -v -n
echo ""
echo "  ── mangle table ──"
iptables -t mangle -L -v -n
pause

echo "$DIVIDER"
echo "  Experiment 8 Complete! Rules will be flushed on exit."
echo "$DIVIDER"
