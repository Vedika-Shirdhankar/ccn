import socket
import threading

HOST = '127.0.0.1'
PORT = 5000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind((HOST, PORT))

server.listen()

print("Advanced Chat Server Running...")

clients = {}

def broadcast(message, sender):

    for username, conn in clients.items():

        if username != sender:

            conn.send(message.encode())

def handle_client(conn, addr):

    username = conn.recv(1024).decode()

    clients[username] = conn

    print(f"{username} connected.")

    while True:

        try:

            message = conn.recv(1024).decode()

            if not message:
                break

            # DIRECT MESSAGE
            if message.startswith('@'):

                parts = message.split(' ', 1)

                target_user = parts[0][1:]

                private_msg = parts[1]

                if target_user in clients:

                    clients[target_user].send(
                        f"[Private] {username}: {private_msg}".encode()
                    )

            # GROUP MESSAGE
            else:

                broadcast(f"{username}: {message}", username)

        except:
            break

    del clients[username]

    conn.close()

    print(f"{username} disconnected.")

while True:

    conn, addr = server.accept()

    thread = threading.Thread(target=handle_client, args=(conn, addr))

    thread.start()