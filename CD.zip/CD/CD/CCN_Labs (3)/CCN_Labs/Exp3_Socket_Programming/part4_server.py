#!/usr/bin/env python3
"""
Experiment 3 - Part 4: Advanced Chat Server (Group + Direct Messages)

Run this first. Clients use part4_client.py.
Usage in client:
  - Normal message  → broadcast to all
  - @username msg   → direct message (DM) to that user
"""
import socket
import threading

clients = {}  # name -> socket
lock    = threading.Lock()

def broadcast(message, sender_name=None):
    with lock:
        for name, sock in list(clients.items()):
            if name != sender_name:
                try:
                    sock.send(message)
                except:
                    sock.close()
                    del clients[name]

def handle_client(conn, addr):
    try:
        conn.send(b"Enter your name: ")
        name = conn.recv(1024).decode().strip()

        with lock:
            if name in clients:
                conn.send(b"  [Name already taken. Disconnecting.]\n")
                conn.close()
                return
            clients[name] = conn

        print(f"  [{name}] joined from {addr}")
        broadcast(f"\n  --- {name} has joined the chat ---\n".encode(), name)
        conn.send(f"  Welcome {name}!\n"
                  f"  Tip: Use @username <msg> for direct messages.\n".encode())

        while True:
            message = conn.recv(1024).decode().strip()
            if not message:
                break

            if message.startswith("@"):
                # Direct message: @target_name the message text
                parts = message.split(None, 1)
                target_name = parts[0][1:]
                msg_body    = parts[1] if len(parts) > 1 else ""
                with lock:
                    target_sock = clients.get(target_name)
                if target_sock:
                    target_sock.send(f"\n  [DM from {name}]: {msg_body}\n".encode())
                    conn.send(f"  [DM to {target_name}]: {msg_body}\n".encode())
                    print(f"  [DM] {name} → {target_name}: {msg_body}")
                else:
                    conn.send(f"  [Error] User '{target_name}' not found.\n".encode())
            else:
                # Group broadcast
                print(f"  [{name}]: {message}")
                broadcast(f"\n  [{name}]: {message}\n".encode(), name)

    except:
        pass
    finally:
        with lock:
            clients.pop(name, None)
        broadcast(f"\n  --- {name} has left ---\n".encode())
        conn.close()
        print(f"  [{name}] disconnected.")

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind(('0.0.0.0', 5003))
server.listen()
print("=" * 55)
print("  Part 4 Advanced Chat Server on port 5003")
print("  Run: python3 part4_client.py in multiple terminals")
print("  Group msg  : just type text")
print("  Direct msg : @username message")
print("  Press Ctrl+C to stop.")
print("=" * 55)
try:
    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()
except KeyboardInterrupt:
    print("\n  Server shutting down.")
finally:
    server.close()
