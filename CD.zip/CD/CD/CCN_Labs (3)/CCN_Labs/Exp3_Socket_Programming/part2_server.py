#!/usr/bin/env python3
"""
Experiment 3 - Part 2: Concurrent TCP Server (multi-threaded)

Run this FIRST, then run multiple part2_client.py instances in separate terminals.
"""
import socket
import threading

def handle_client(conn, addr):
    print(f"  [NEW CONNECTION] {addr} connected.")
    try:
        data = conn.recv(4096).decode()
        if data:
            num_chars     = len(data.strip('\n'))
            num_words     = len(data.split())
            num_sentences = data.count('.')
            response = (f"Characters: {num_chars}, "
                        f"Words: {num_words}, "
                        f"Sentences: {num_sentences}")
            conn.sendall(response.encode())
    except Exception as e:
        print(f"  [ERROR] {addr}: {e}")
    finally:
        conn.close()
        print(f"  [DISCONNECTED] {addr}")

def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(('0.0.0.0', 6002))
    server.listen()
    print("=" * 55)
    print("  Part 2 Concurrent Server listening on port 6002")
    print("  Open multiple terminals and run part2_client.py")
    print("  Press Ctrl+C to stop the server.")
    print("=" * 55)
    try:
        while True:
            conn, addr = server.accept()
            thread = threading.Thread(target=handle_client, args=(conn, addr))
            thread.daemon = True
            thread.start()
            print(f"  [ACTIVE CONNECTIONS] {threading.active_count() - 1}")
    except KeyboardInterrupt:
        print("\n  Server shutting down.")
    finally:
        server.close()

if __name__ == "__main__":
    start_server()
