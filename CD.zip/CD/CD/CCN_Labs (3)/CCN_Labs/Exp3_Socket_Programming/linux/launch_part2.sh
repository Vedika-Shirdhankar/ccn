#!/bin/bash
# ============================================================
# Exp3 Part 2 — Auto-launcher (server + 2 clients, split panes)
# Demonstrates the concurrent multi-threaded server
# ============================================================
DIR="$(cd "$(dirname "$0")/.." && pwd)"

launch_tmux() {
    tmux kill-session -t exp3_p2 2>/dev/null
    tmux new-session -d -s exp3_p2 -x 220 -y 55

    tmux rename-window -t exp3_p2 "Exp3-Part2"

    # Top-left: server
    tmux send-keys -t exp3_p2 "echo '=== SERVER (port 6002) ===' && python3 '$DIR/part2_server.py'" Enter

    # Top-right: client 1
    tmux split-window -h -t exp3_p2
    tmux send-keys -t exp3_p2 "sleep 1 && echo '=== CLIENT 1 ===' && python3 '$DIR/part2_client.py'" Enter

    # Bottom-right: client 2
    tmux split-window -v -t exp3_p2:0.1
    tmux send-keys -t exp3_p2 "sleep 1 && echo '=== CLIENT 2 ===' && python3 '$DIR/part2_client.py'" Enter

    tmux select-pane -t exp3_p2:0.0
    echo ""
    echo "  Attaching tmux session..."
    echo "  Layout: [Server | Client1 / Client2]"
    echo "  Ctrl+B then arrow keys to switch panes | Ctrl+B D to detach"
    echo ""
    sleep 1
    tmux attach-session -t exp3_p2
}

launch_xterm() {
    xterm -title "Exp3 P2 SERVER" -geometry 80x24+0+0 \
        -e "python3 '$DIR/part2_server.py'; read -p 'Press Enter...'" &
    sleep 1
    xterm -title "Exp3 P2 CLIENT-1" -geometry 80x24+800+0 \
        -e "python3 '$DIR/part2_client.py'; read -p 'Press Enter...'" &
    sleep 0.3
    xterm -title "Exp3 P2 CLIENT-2" -geometry 80x24+800+300 \
        -e "python3 '$DIR/part2_client.py'; read -p 'Press Enter...'"
}

launch_gnome() {
    gnome-terminal --title="Exp3 P2 SERVER"   -- bash -c "python3 '$DIR/part2_server.py'; read -p 'Press Enter...'" &
    sleep 1
    gnome-terminal --title="Exp3 P2 CLIENT-1" -- bash -c "python3 '$DIR/part2_client.py'; read -p 'Press Enter...'" &
    sleep 0.3
    gnome-terminal --title="Exp3 P2 CLIENT-2" -- bash -c "python3 '$DIR/part2_client.py'; read -p 'Press Enter...'"
}

echo ""
echo "  Exp3 Part 2 — Concurrent TCP Server (multi-threaded)"
echo "  Launching 1 server + 2 clients automatically..."
echo ""

if command -v tmux &>/dev/null; then
    launch_tmux
elif command -v gnome-terminal &>/dev/null; then
    launch_gnome
elif command -v xterm &>/dev/null; then
    launch_xterm
else
    echo "  [TIP] Install tmux for automatic multi-pane launch:  sudo apt install tmux"
    echo ""
    echo "  Starting server in this terminal."
    echo "  Open 2 MORE terminals and run in each:"
    echo "    python3 $DIR/part2_client.py"
    echo ""
    python3 "$DIR/part2_server.py"
fi
