import socket
import threading

HOST = '127.0.0.1'
PORT = 5000

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind((HOST, PORT))

server.listen()

print("Concurrent Server Running...")

def handle_client(conn, addr):

    print(f"Connected by {addr}")

    data = conn.recv(1024).decode()

    characters = len(data)
    words = len(data.split())
    sentences = data.count('.')

    result = f"Characters: {characters}\nWords: {words}\nSentences: {sentences}"

    conn.send(result.encode())

    conn.close()

while True:

    conn, addr = server.accept()

    thread = threading.Thread(target=handle_client, args=(conn, addr))

    thread.start()