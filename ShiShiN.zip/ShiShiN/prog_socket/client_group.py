import socket
import threading

HOST = '127.0.0.1'
PORT = 5000

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect((HOST, PORT))

username = input("Enter username: ")

client.send(username.encode())

def receive():

    while True:

        try:
            message = client.recv(1024).decode()

            print(message)

        except:
            break

def send():

    while True:

        message = input()

        client.send(message.encode())

receive_thread = threading.Thread(target=receive)

send_thread = threading.Thread(target=send)

receive_thread.start()

send_thread.start()