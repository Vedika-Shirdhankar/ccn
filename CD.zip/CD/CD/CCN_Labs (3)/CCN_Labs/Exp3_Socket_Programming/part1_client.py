#!/usr/bin/env python3
"""
Experiment 3 - Part 1: TCP String Processing Client

Run part1_server.py FIRST, then run this script.
"""
import socket

def start_client():
    HOST = input("Enter server IP (press Enter for localhost): ").strip() or '127.0.0.1'
    PORT = 6001

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((HOST, PORT))
    print(f"  Connected to server at {HOST}:{PORT}")

    paragraph = input("Enter a paragraph (use '.' to end sentences): ") + "\n"
    client_socket.sendall(paragraph.encode())

    data = client_socket.recv(4096).decode()
    print("\n  ── Server Response ──")
    print(f"  {data.replace(chr(10), chr(10) + '  ')}")

    client_socket.close()

if __name__ == "__main__":
    start_client()
