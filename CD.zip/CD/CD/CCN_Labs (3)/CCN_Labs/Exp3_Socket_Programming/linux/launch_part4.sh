#!/bin/bash
# ============================================================
# Exp3 Part 4 — Auto-launcher (Advanced Chat: group + DMs)
# ============================================================
DIR="$(cd "$(dirname "$0")/.." && pwd)"

launch_tmux() {
    tmux kill-session -t exp3_p4 2>/dev/null
    tmux new-session -d -s exp3_p4 -x 220 -y 55

    tmux rename-window -t exp3_p4 "Exp3-Part4-DM"

    # Left: server
    tmux send-keys -t exp3_p4 "echo '=== ADVANCED CHAT SERVER (port 5003) ===' && python3 '$DIR/part4_server.py'" Enter

    # Top-right: client 1
    tmux split-window -h -t exp3_p4
    tmux send-keys -t exp3_p4 "sleep 1 && echo '=== CLIENT 1 (enter name, then chat) ===' && python3 '$DIR/part4_client.py'" Enter

    # Bottom-right: client 2
    tmux split-window -v -t exp3_p4:0.1
    tmux send-keys -t exp3_p4 "sleep 1 && echo '=== CLIENT 2 (enter name, then chat) ===' && python3 '$DIR/part4_client.py'" Enter

    tmux select-pane -t exp3_p4:0.1
    echo ""
    echo "  Attaching tmux session (Advanced Chat + DMs)..."
    echo "  Enter a name in each client to join."
    echo "  Type a message to broadcast  |  @name msg to DM someone"
    echo "  Ctrl+B arrow keys = switch panes | Ctrl+B D = detach"
    echo ""
    sleep 1
    tmux attach-session -t exp3_p4
}

launch_gnome() {
    gnome-terminal --title="Exp3 P4 SERVER"   -- bash -c "python3 '$DIR/part4_server.py'; read -p 'Press Enter...'" &
    sleep 1
    gnome-terminal --title="Exp3 P4 Client-1" -- bash -c "python3 '$DIR/part4_client.py'; read -p 'Press Enter...'" &
    sleep 0.3
    gnome-terminal --title="Exp3 P4 Client-2" -- bash -c "python3 '$DIR/part4_client.py'; read -p 'Press Enter...'"
}

launch_xterm() {
    xterm -title "Exp3 P4 SERVER"   -geometry 80x24+0+0   -e "python3 '$DIR/part4_server.py'; read -p 'Press Enter...'" &
    sleep 1
    xterm -title "Exp3 P4 Client-1" -geometry 80x24+820+0 -e "python3 '$DIR/part4_client.py'; read -p 'Press Enter...'" &
    sleep 0.3
    xterm -title "Exp3 P4 Client-2" -geometry 80x24+820+300 -e "python3 '$DIR/part4_client.py'; read -p 'Press Enter...'"
}

echo ""
echo "  Exp3 Part 4 — Advanced Chat (Group + Direct Messages)"
echo "  Launching server + 2 clients..."
echo ""

if command -v tmux &>/dev/null; then
    launch_tmux
elif command -v gnome-terminal &>/dev/null; then
    launch_gnome
elif command -v xterm &>/dev/null; then
    launch_xterm
else
    echo "  [TIP] Install tmux:  sudo apt install tmux"
    echo ""
    echo "  Starting server here. Open 2 more terminals and run:"
    echo "    python3 $DIR/part4_client.py"
    echo "  Direct message syntax:  @username your message"
    echo ""
    python3 "$DIR/part4_server.py"
fi
