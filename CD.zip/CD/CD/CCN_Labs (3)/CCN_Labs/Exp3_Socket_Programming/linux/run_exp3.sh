#!/bin/bash
# ============================================================
# Exp3_Socket_Programming — Linux Runner
# ============================================================
DIVIDER="============================================================"
DIR="$(cd "$(dirname "$0")" && pwd)"
PYDIR="$(cd "$DIR/.." && pwd)"

show_menu() {
    clear
    echo ""
    echo "$DIVIDER"
    echo "  Exp3 — Socket Programming"
    echo "$DIVIDER"
    echo ""
    echo "  AUTO-LAUNCH (opens server + client(s) in split panes):"
    echo "  ─────────────────────────────────────────────────────"
    echo "   1) Part 1 — Iterative server + client     [2 panes]"
    echo "   2) Part 2 — Concurrent server + 2 clients [3 panes]"
    echo "   3) Part 3 — Group chat + 2 clients        [3 panes]"
    echo "   4) Part 4 — Advanced chat (group + DMs) + 2 clients"
    echo ""
    echo "  MANUAL (run one component at a time):"
    echo "  ─────────────────────────────────────────────────────"
    echo "   5) Part 1 Server only"
    echo "   6) Part 1 Client only"
    echo "   7) Part 2 Server only"
    echo "   8) Part 2 Client only"
    echo "   9) Part 3 Server only"
    echo "  10) Part 3 Client only"
    echo "  11) Part 4 Server only"
    echo "  12) Part 4 Client only"
    echo ""
    echo "   0) Back to main menu"
    echo ""
    echo "$DIVIDER"
    echo ""
}

while true; do
    show_menu
    read -p "  Enter choice: " choice
    echo ""
    case $choice in
        1)  bash "$DIR/launch_part1.sh" ;;
        2)  bash "$DIR/launch_part2.sh" ;;
        3)  bash "$DIR/launch_part3.sh" ;;
        4)  bash "$DIR/launch_part4.sh" ;;
        5)  python3 "$PYDIR/part1_server.py" ;;
        6)  python3 "$PYDIR/part1_client.py" ;;
        7)  python3 "$PYDIR/part2_server.py" ;;
        8)  python3 "$PYDIR/part2_client.py" ;;
        9)  python3 "$PYDIR/part3_server.py" ;;
       10)  python3 "$PYDIR/part3_client.py" ;;
       11)  python3 "$PYDIR/part4_server.py" ;;
       12)  python3 "$PYDIR/part4_client.py" ;;
        0)  exit 0 ;;
        *)  echo "  Invalid choice." ; sleep 1 ;;
    esac
    echo ""
    read -p "  [Press Enter to return to Exp3 menu...] " _
done
