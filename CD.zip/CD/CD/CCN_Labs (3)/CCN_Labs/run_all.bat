@echo off
:: ============================================================
::  CCN Labs — Main Menu (Windows)
::  Computer Communication and Networks — A.Y. 2025-26
:: ============================================================

:: Detect correct python command
set PYEXE=
py --version >nul 2>&1 && set PYEXE=py
if "%PYEXE%"=="" (python3 --version >nul 2>&1 && set PYEXE=python3)
if "%PYEXE%"=="" (python --version >nul 2>&1 && set PYEXE=python)
if "%PYEXE%"=="" (
    echo.
    echo   [WARNING] Python not found. Socket/Scapy experiments won't run.
    echo   Install from https://python.org and tick "Add Python to PATH"
    echo   Continuing anyway for networking commands...
    echo.
    pause
)

:menu
cls
echo.
echo ============================================================
echo    CCN LABS -- MAIN MENU  (Windows)
if not "%PYEXE%"=="" echo    Python: %PYEXE%
echo ============================================================
echo.
echo    TERMINAL EXPERIMENTS:
echo    --------------------------------------------------------
echo    1) Exp1_Linux_Commands       -- Basic Networking Commands
echo    2) Exp3_Socket_Programming   -- Socket Programming (Python)
echo    3) Exp6_Nmap                 -- Network Mapping using Nmap
echo    4) Exp7_Scapy                -- Packet Crafting using Scapy
echo    5) Exp8_iptables             -- iptables (Linux only, see note)
echo.
echo    GUI / MANUAL EXPERIMENTS:
echo    --------------------------------------------------------
echo    6) Exp2_ChromeDevTools       -- Chrome DevTools
echo    7) Exp4_CiscoPacketTracer    -- Cisco Packet Tracer Subnetting
echo    8) ExpWireshark_HTTP         -- Wireshark HTTP Lab
echo    9) Exp10_CiscoProject        -- Cisco Packet Tracer Hotel Project
echo.
echo    0) Exit
echo.
echo ============================================================
echo.
set /p choice="   Enter choice: "

if "%choice%"=="1" call "%~dp0Exp1_Linux_Commands\windows\exp1_networking_commands.bat" & goto menu
if "%choice%"=="2" call "%~dp0Exp3_Socket_Programming\windows\run_exp3.bat"             & goto menu
if "%choice%"=="3" call "%~dp0Exp6_Nmap\windows\exp6_nmap.bat"                         & goto menu
if "%choice%"=="4" call "%~dp0Exp7_Scapy\windows\run_exp7.bat"                         & goto menu
if "%choice%"=="5" (
    echo.
    type "%~dp0Exp8_iptables\windows\README_windows.txt"
    echo.
    pause
    goto menu
)
if "%choice%"=="6" notepad "%~dp0GUI_EXPERIMENTS_INSTRUCTIONS.txt" & goto menu
if "%choice%"=="7" notepad "%~dp0GUI_EXPERIMENTS_INSTRUCTIONS.txt" & goto menu
if "%choice%"=="8" notepad "%~dp0GUI_EXPERIMENTS_INSTRUCTIONS.txt" & goto menu
if "%choice%"=="9" notepad "%~dp0GUI_EXPERIMENTS_INSTRUCTIONS.txt" & goto menu
if "%choice%"=="0" goto end
echo    Invalid choice.
pause
goto menu

:end
echo    Goodbye!
