@echo off
:: ============================================================
:: Exp7_Scapy — Windows Runner
:: Requires: pip install scapy  AND  Npcap (https://npcap.com)
:: Run as Administrator for raw socket access
:: ============================================================

:: Detect correct python command
set PYEXE=
py --version >nul 2>&1 && set PYEXE=py
if "%PYEXE%"=="" (python3 --version >nul 2>&1 && set PYEXE=python3)
if "%PYEXE%"=="" (python --version >nul 2>&1 && set PYEXE=python)
if "%PYEXE%"=="" (
    echo.
    echo   [ERROR] Python not found.
    echo   Install from https://python.org and tick "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   Exp7 -- Packet Crafting using Scapy (Windows)
echo   Using: %PYEXE%
echo ============================================================
echo.

:: Check Scapy
%PYEXE% -c "from scapy.all import IP" >nul 2>&1
if %errorlevel% neq 0 (
    echo   Scapy not installed. Installing...
    %PYEXE% -m pip install scapy
    echo.
)

echo   [NOTE] Scapy on Windows requires Npcap for packet capture.
echo   If you see errors, download Npcap from: https://npcap.com
echo   Run this script as Administrator for raw socket access.
echo.
echo   Starting Scapy experiments...
echo.

%PYEXE% "%~dp0..\exp7_scapy.py"
echo.
pause
