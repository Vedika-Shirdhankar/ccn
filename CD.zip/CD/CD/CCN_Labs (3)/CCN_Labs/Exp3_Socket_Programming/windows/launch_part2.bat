@echo off
:: ============================================================
:: Exp3 Part 2 — Windows Auto-Launcher
:: Opens SERVER + 2 CLIENTS in separate command windows
:: ============================================================
set PYDIR=%~dp0..

:: Detect correct python command
set PYEXE=
py --version >nul 2>&1 && set PYEXE=py
if "%PYEXE%"=="" (python3 --version >nul 2>&1 && set PYEXE=python3)
if "%PYEXE%"=="" (python --version >nul 2>&1 && set PYEXE=python)
if "%PYEXE%"=="" (
    echo.
    echo   [ERROR] Python not found.
    echo   Install from https://python.org and tick "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

echo.
echo   Exp3 Part 2 -- Concurrent TCP Server
echo   Using: %PYEXE%
echo   Launching 3 windows: 1 server + 2 clients...
echo.

start "Exp3-P2 SERVER (port 6002)" cmd /k "echo === SERVER === && %PYEXE% "%PYDIR%\part2_server.py""
timeout /t 1 /nobreak > nul
start "Exp3-P2 CLIENT-1" cmd /k "echo === CLIENT 1 === && %PYEXE% "%PYDIR%\part2_client.py""
start "Exp3-P2 CLIENT-2" cmd /k "echo === CLIENT 2 === && %PYEXE% "%PYDIR%\part2_client.py""

echo   Done! 3 windows opened.
echo.
pause
