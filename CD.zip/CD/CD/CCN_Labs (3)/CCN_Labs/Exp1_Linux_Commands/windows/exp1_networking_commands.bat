@echo off
:: ============================================================
:: Exp1_Linux_Commands — Windows equivalent (ipconfig, netstat, etc.)
:: ============================================================
setlocal

set DIVIDER=============================================================

:menu
cls
echo.
echo %DIVIDER%
echo   Exp1 — Basic Windows Networking Commands
echo %DIVIDER%
echo.
echo   1)  ipconfig         — IP configuration
echo   2)  ipconfig /all    — Detailed adapter info
echo   3)  ping             — Connectivity test
echo   4)  tracert          — Trace route to host
echo   5)  netstat -an      — Active connections
echo   6)  arp -a           — ARP table
echo   7)  nslookup         — DNS lookup
echo   8)  hostname         — System hostname
echo   9)  route print      — Routing table
echo  10)  Run ALL (one after another)
echo.
echo   0)  Exit
echo.
echo %DIVIDER%
echo.
set /p choice="  Enter choice: "

if "%choice%"=="1"  goto ipconfig_basic
if "%choice%"=="2"  goto ipconfig_all
if "%choice%"=="3"  goto ping_test
if "%choice%"=="4"  goto tracert_test
if "%choice%"=="5"  goto netstat_test
if "%choice%"=="6"  goto arp_test
if "%choice%"=="7"  goto nslookup_test
if "%choice%"=="8"  goto hostname_test
if "%choice%"=="9"  goto route_test
if "%choice%"=="10" goto run_all
if "%choice%"=="0"  goto end
echo   Invalid choice.
pause
goto menu

:ipconfig_basic
echo.
echo %DIVIDER%
echo   ipconfig
echo %DIVIDER%
ipconfig
echo.
pause
goto menu

:ipconfig_all
echo.
echo %DIVIDER%
echo   ipconfig /all
echo %DIVIDER%
ipconfig /all
echo.
pause
goto menu

:ping_test
echo.
set /p host="  Enter hostname or IP to ping [default: google.com]: "
if "%host%"=="" set host=google.com
echo %DIVIDER%
echo   ping %host%
echo %DIVIDER%
ping %host%
echo.
pause
goto menu

:tracert_test
echo.
set /p host="  Enter hostname or IP for tracert [default: google.com]: "
if "%host%"=="" set host=google.com
echo %DIVIDER%
echo   tracert %host%
echo %DIVIDER%
tracert %host%
echo.
pause
goto menu

:netstat_test
echo.
echo %DIVIDER%
echo   netstat -an
echo %DIVIDER%
netstat -an
echo.
pause
goto menu

:arp_test
echo.
echo %DIVIDER%
echo   arp -a
echo %DIVIDER%
arp -a
echo.
pause
goto menu

:nslookup_test
echo.
set /p host="  Enter domain to lookup [default: google.com]: "
if "%host%"=="" set host=google.com
echo %DIVIDER%
echo   nslookup %host%
echo %DIVIDER%
nslookup %host%
echo.
pause
goto menu

:hostname_test
echo.
echo %DIVIDER%
echo   hostname
echo %DIVIDER%
hostname
echo.
pause
goto menu

:route_test
echo.
echo %DIVIDER%
echo   route print
echo %DIVIDER%
route print
echo.
pause
goto menu

:run_all
echo.
echo   Running all networking commands...
echo.
echo %DIVIDER% & echo   ipconfig /all & echo %DIVIDER%
ipconfig /all
echo. & pause

echo %DIVIDER% & echo   ping google.com & echo %DIVIDER%
ping google.com
echo. & pause

echo %DIVIDER% & echo   netstat -an & echo %DIVIDER%
netstat -an
echo. & pause

echo %DIVIDER% & echo   arp -a & echo %DIVIDER%
arp -a
echo. & pause

echo %DIVIDER% & echo   nslookup google.com & echo %DIVIDER%
nslookup google.com
echo. & pause

echo %DIVIDER% & echo   hostname & echo %DIVIDER%
hostname
echo. & pause

echo %DIVIDER% & echo   route print & echo %DIVIDER%
route print
echo. & pause
goto menu

:end
echo   Goodbye!
endlocal
