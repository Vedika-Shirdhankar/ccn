#!/bin/bash
# ============================================================
# Experiment 1: Basic Linux Networking Commands

# Objective: Study and implement basic networking commands in
#            Linux for configuration, connectivity & troubleshooting
# ============================================================

DIVIDER="============================================================"

pause() {
    echo ""
    read -p "  [Press Enter to continue to next command...] " _
    echo ""
}

banner() {
    echo ""
    echo "$DIVIDER"
    echo "  $1"
    echo "$DIVIDER"
}

echo ""
echo "$DIVIDER"
echo "  EXPERIMENT 1 — Basic Linux Networking Commands"
echo "$DIVIDER"
echo "  Each command will run and pause for you to observe output."
echo ""
read -p "  [Press Enter to begin...] " _

# ─────────────────────────────────────────────────────────────
banner "1. ifconfig / ip addr — Network Interface Information"
echo "  Description: Displays IP addresses, MAC addresses, and interface status."
echo ""
echo "  ── Command: ifconfig ──"
ifconfig 2>/dev/null || ip addr show
pause

echo "  ── Command: ip addr show ──"
ip addr show
pause

# ─────────────────────────────────────────────────────────────
banner "2. ping — Test Network Connectivity"
echo "  Description: Sends ICMP echo requests to test reachability and measure RTT."
echo ""
echo "  ── Command: ping -c 5 google.com ──"
ping -c 5 google.com 2>/dev/null || echo "  [Note: ping blocked or no internet access]"
pause

echo "  ── Command: ping -c 4 -s 128 google.com ──"
ping -c 4 -s 128 google.com 2>/dev/null || echo "  [Note: ping blocked or no internet access]"
pause

echo "  ── Command: ping -c 4 127.0.0.1 (loopback test) ──"
ping -c 4 127.0.0.1
pause

# ─────────────────────────────────────────────────────────────
banner "3. netstat / ss — Network Connections and Ports"
echo "  Description: Displays active connections, listening ports, and routing tables."
echo ""
echo "  ── Command: ss -tuln (listening TCP/UDP ports) ──"
ss -tuln
pause

echo "  ── Command: netstat -tuln ──"
netstat -tuln 2>/dev/null || echo "  [netstat not installed; ss is the modern replacement]"
pause

echo "  ── Command: netstat -r (routing table) ──"
netstat -r 2>/dev/null || ip route show
pause

# ─────────────────────────────────────────────────────────────
banner "4. traceroute / tracepath — Trace Network Path"
echo "  Description: Shows each router hop from source to destination."
echo ""
echo "  ── Command: traceroute -m 15 google.com ──"
traceroute -m 15 google.com 2>/dev/null || tracepath -m 15 google.com 2>/dev/null || echo "  [traceroute not available; try: sudo apt install traceroute]"
pause

# ─────────────────────────────────────────────────────────────
banner "5. arp — ARP Cache (IP-to-MAC Mappings)"
echo "  Description: Shows how IP addresses map to MAC addresses on the local network."
echo ""
echo "  ── Command: arp -a ──"
arp -a 2>/dev/null || ip neigh show
pause

echo "  ── Command: ip neigh show (modern replacement) ──"
ip neigh show
pause

# ─────────────────────────────────────────────────────────────
banner "6. nslookup / dig / host — DNS Lookup"
echo "  Description: Resolves domain names to IP addresses via DNS."
echo ""
echo "  ── Command: nslookup google.com ──"
nslookup google.com 2>/dev/null || echo "  [nslookup not installed; try: sudo apt install dnsutils]"
pause

echo "  ── Command: dig google.com ──"
dig google.com 2>/dev/null || echo "  [dig not installed; try: sudo apt install dnsutils]"
pause

echo "  ── Command: host -t MX google.com ──"
host -t MX google.com 2>/dev/null || echo "  [host not installed; try: sudo apt install bind9-host]"
pause

# ─────────────────────────────────────────────────────────────
banner "7. hostname — System Hostname"
echo "  Description: Displays or sets the system's hostname."
echo ""
echo "  ── Command: hostname ──"
hostname
echo ""
echo "  ── Command: hostname -f (FQDN) ──"
hostname -f 2>/dev/null || hostname
echo ""
echo "  ── Command: hostname -I (all IP addresses) ──"
hostname -I
pause

# ─────────────────────────────────────────────────────────────
banner "8. route / ip route — Routing Table"
echo "  Description: Displays and manages the kernel routing table."
echo ""
echo "  ── Command: ip route show ──"
ip route show
pause

echo "  ── Command: route -n ──"
route -n 2>/dev/null || ip route show
pause

echo "  ── Command: ip route get 8.8.8.8 ──"
ip route get 8.8.8.8

echo ""
echo "$DIVIDER"
echo "  Experiment 1 Complete!"
echo "  All 8 Linux networking commands have been demonstrated."
echo "$DIVIDER"
echo ""
