# CCN Labs — Computer Communication and Networks
**A.Y.:** 2025-26

---

## Quick Start

### Linux
```bash
unzip CCN_Labs.zip && cd CCN_Labs
chmod +x run_all.sh
bash run_all.sh
```

### Windows
```
Double-click  run_all.bat
(or right-click → Run as Administrator for Scapy/Nmap)
```

---

## Folder Structure

Each experiment has `linux/` and `windows/` subfolders with platform-specific runners.
Python scripts (socket programming, scapy) are shared and sit at the experiment root.

```
CCN_Labs/
├── run_all.sh                          ← Linux main menu
├── run_all.bat                         ← Windows main menu
│
├── Exp1_Linux_Commands/
│   ├── linux/   exp1_networking_commands.sh
│   └── windows/ exp1_networking_commands.bat
│
├── Exp3_Socket_Programming/
│   ├── part1_server.py  part1_client.py   ← shared Python files
│   ├── part2_server.py  part2_client.py
│   ├── part3_server.py  part3_client.py
│   ├── part4_server.py  part4_client.py
│   ├── linux/
│   │   ├── run_exp3.sh          ← sub-menu
│   │   ├── launch_part1.sh      ← auto-opens server + client
│   │   ├── launch_part2.sh      ← auto-opens server + 2 clients
│   │   ├── launch_part3.sh      ← auto-opens chat server + 2 clients
│   │   └── launch_part4.sh      ← auto-opens DM server + 2 clients
│   └── windows/
│       ├── run_exp3.bat
│       └── launch_part2.bat
│
├── Exp6_Nmap/
│   ├── linux/   exp6_nmap.sh
│   └── windows/ exp6_nmap.bat
│
├── Exp7_Scapy/
│   ├── exp7_scapy.py              ← shared (Linux + Windows)
│   ├── linux/   run_exp7.sh
│   └── windows/ run_exp7.bat
│
├── Exp8_iptables/
│   ├── linux/   exp8_iptables.sh
│   └── windows/ README_windows.txt   ← WSL instructions
│
└── GUI_EXPERIMENTS_INSTRUCTIONS.txt   ← Exp2, Exp4, Wireshark, Exp10
```

---

## Experiment Overview

| Exp | Folder | Linux | Windows |
|-----|--------|-------|---------|
| 1  | Exp1_Linux_Commands | `linux/exp1_networking_commands.sh` | `windows/exp1_networking_commands.bat` |
| 2  | GUI | `GUI_EXPERIMENTS_INSTRUCTIONS.txt` | same |
| 3  | Exp3_Socket_Programming | `linux/run_exp3.sh` | `windows/run_exp3.bat` |
| 4  | GUI | `GUI_EXPERIMENTS_INSTRUCTIONS.txt` | same |
| 6  | Exp6_Nmap | `linux/exp6_nmap.sh` | `windows/exp6_nmap.bat` |
| 7  | Exp7_Scapy | `linux/run_exp7.sh` | `windows/run_exp7.bat` |
| 8  | Exp8_iptables | `linux/exp8_iptables.sh` | `windows/README_windows.txt` (WSL) |
| WS | GUI | `GUI_EXPERIMENTS_INSTRUCTIONS.txt` | same |
| 10 | GUI | `GUI_EXPERIMENTS_INSTRUCTIONS.txt` | same |

---

## Exp3 Socket Programming — Auto-Launch

The launch scripts automatically open all needed terminals at once.
On Linux they use **tmux** (recommended) or gnome-terminal / xterm as fallback.
On Windows they open separate **cmd** windows.

| Part | What it does | Terminals |
|------|-------------|-----------|
| 1 | Iterative server — processes one client, returns char/word/sentence count | 2 |
| 2 | Concurrent server — handles multiple clients via threads | 3 |
| 3 | Group chat — broadcast messages to all connected users | 3+ |
| 4 | Group + DMs — broadcast + `@username` direct messages | 3+ |

**Install tmux for best experience:**
```bash
sudo apt install tmux
# In tmux: Ctrl+B arrow = switch panes | Ctrl+B D = detach
```

---

## Dependencies

### Linux
```bash
sudo apt update
sudo apt install -y nmap traceroute net-tools dnsutils python3 python3-pip tmux
sudo pip3 install scapy --break-system-packages
```

### Windows
- Python 3: https://python.org (add to PATH)
- Nmap: https://nmap.org/download.html (add to PATH)
- Scapy: `pip install scapy` + Npcap from https://npcap.com
- iptables: use WSL — see `Exp8_iptables/windows/README_windows.txt`

---

## GUI Experiments

Full step-by-step instructions for Exp2, Exp4, Wireshark, and Exp10 are in:
```
GUI_EXPERIMENTS_INSTRUCTIONS.txt
```
