#!/bin/bash
# ============================================================
# Experiment 7 — Scapy Packet Crafting Runner
# ============================================================
DIVIDER="============================================================"
DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "$DIVIDER"
echo "  EXPERIMENT 7 — Packet Crafting using Scapy"
echo "$DIVIDER"
echo ""

# Check Python
if ! command -v python3 &>/dev/null; then
    echo "  [ERROR] python3 not found. Install it first."
    exit 1
fi

# Check Scapy
python3 -c "from scapy.all import IP" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "  Scapy not installed. Installing..."
    sudo pip3 install scapy --break-system-packages 2>/dev/null || \
    pip3 install scapy 2>/dev/null
    echo ""
fi

echo "  Running Scapy packet crafting experiments..."
echo "  (Requires sudo / root)"
echo ""
sudo python3 "$DIR/exp7_scapy.py"
