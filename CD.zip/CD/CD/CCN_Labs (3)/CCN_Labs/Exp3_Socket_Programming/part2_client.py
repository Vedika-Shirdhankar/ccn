#!/usr/bin/env python3
"""
Experiment 3 - Part 2: Concurrent TCP Client

Run multiple instances of this in separate terminals to test concurrency.
"""
import socket

def start_client():
    HOST = input("Enter server IP (press Enter for localhost): ").strip() or '127.0.0.1'
    PORT = 6002

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((HOST, PORT))
    print(f"  Connected to server at {HOST}:{PORT}")

    paragraph = input("Enter a paragraph (use '.' to end sentences): ") + "\n"
    client_socket.sendall(paragraph.encode())

    data = client_socket.recv(4096).decode()
    print(f"\n  Server Response: {data}")
    client_socket.close()

if __name__ == "__main__":
    start_client()
